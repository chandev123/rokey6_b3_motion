## Project H.I.T - Refined Node Architecture Specification

[연동할 시뮬레이션 명령어]
ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=virtual host:=127.0.0.1 port:=12345 model:=m0609

ros2 launch dsr_bringup2 dsr_bringup2_rviz.launch.py mode:=real host:=192.168.1.100 port:=12345 model:=m0609

[node 목록]


[검토 명령어]
-현재 위치
ros2 topic pub --once /user/command std_msgs/msg/String "{data: 'p'}"
-위치 변경 명령
ros2 topic pub --once /user/command std_msgs/msg/String "{data: 's'}"

ros2 run project_hit hw
ros2 run project_hit task

[시뮬레이터 확인 및 정리]
ps aux | grep -E "dsr|drcf|emulator"

pkill -f dsr
sudo pkill -9 -f dsr

pkill -f ros2

[기본구조] 모든 노드에 API 적용
import DR_init
import DSR_ROBOT2

--------------------------------------------------------------------------------
0. project_hit_interfaces (메시지 및 액션 타입 정의)
--------------------------------------------------------------------------------
[ 역할 ]
 - 커스텀 메시지 및 액션(.action) 파일 정의
 - Python 노드(ament_python)와 분리하여 안정적인 빌드 환경 제공

[ 정의 항목 ]
  1. **RunRobotAction.action** (Action)
     - **Goal**:
       - command (string)      : 수행할 명령어 ('pick', 'place', 'approach' 등)
       - target_pose (float64[]) : (Optional) 목표 좌표
     - **Result**:
       - success (bool)        : 성공 여부
       - message (string)      : 결과 메시지
     - **Feedback**:
       - current_step (string) : 현재 진행 중인 단계

--------------------------------------------------------------------------------
1. task_node (메인 관제 & 시퀀서)
--------------------------------------------------------------------------------
[ 역할 ]
 - 시스템의 '두뇌': 작업 순서 결정(Sequencer) 및 로봇 직접 제어(Controller)
 - **Current Architecture**: 외부 설정(YAML)을 읽어 `DSR_ROBOT2` API로 직접 로봇을 제어함.

[ 기능 ]
  1. **Task Sequencing**: `pose_config.yaml` 기반의 동적 작업 큐 생성 및 실행.
  2. **Direct Motion Control**: `movej`, `movel` 등의 Motion Command 직접 수행.
  3. **Task Management**: FSM (IDLE -> DECIDE_ORDER -> RUN) 기반 상태 관리.

[ Interface ]
 - Subscriber:
    1. /robot/status       : 로봇(Pose/Joint) 및 힘(Force) 정보 수신
    2. /user/command       : 시작/정지/리셋 명령 수신
 - Publisher:
    1. /robot/servo_cmd    : [Fine Control] 위치 보정값 고주기 스트리밍
 - Action Client:
    1. run_robot_action    : [Gross Control] 시퀀스 단위 명령 요청

--------------------------------------------------------------------------------
2. hw_node (하드웨어 모니터링)
--------------------------------------------------------------------------------
[ 역할 ]
 - 시스템의 '몸': 로봇 암/그리퍼 동기화 및 드라이버 제어

[ 기능 ]
  1. **Status Monitoring**: 로봇 연결(Alive), 서보 상태 등 주기적 확인.
  2. **Hardware Abstraction**: (Future) `task_node`가 사용할 하드웨어 리소스 관리.

[ Interface ] 상태(alive), joint(posj)
 - Publisher:
    1. /robot/status       : 로봇 상태 및 센서 데이터 통합 발행
 - Subscriber:
    1. /robot/servo_cmd    : 실시간 위치 보정 명령 수신
 - Action Server:
    1. run_robot_action    : 시퀀스 명령 수행

--------------------------------------------------------------------------------
3. ui_node (사용자 입력)
--------------------------------------------------------------------------------
[ 역할 ]
 - 외부 트리거(키보드/GUI) 처리 (The Switch)

[ 기능 ]
  1. **Input Handling**: 키보드/버튼 입력 감지
  2. **Emergency Trigger**: 비상 정지 신호 발생

[ Interface ]
 - Publisher:
    1. /user/command       : 사용자 의도 발행

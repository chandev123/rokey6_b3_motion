# Motion Control 분석 문서

## 📋 프로젝트 개요
로봇이 3개의 선반에서 물건을 픽-앤-플레이스하는 작업을 수행하는 모듈입니다.
- **로봇 모델**: Doosan M0609
- **작업**: Stage A (S1→S2), Stage B (S2→S3) 반복 작업
- **프레임워크**: ROS 2 (rclpy)

---

## 🔄 전체 실행 구조

```
main()
├─ ROS 2 초기화 (rclpy.init)
├─ DR_init 설정 (로봇 ID, 모델)
├─ initialize_robot()
│   ├─ set_tool(ROBOT_TOOL)
│   └─ set_tcp(ROBOT_TCP)
├─ perform_task()
│   ├─ stageA_s1_s2_roundtrip_3cycles_no_home()
│   └─ stageB_s2_s3_pick_qs2_via_qmid_tilt_only_3cycles()
├─ do_homing() (선택사항)
├─ go_home()
└─ rclpy.shutdown()
```

---

## 📍 로봇 설정

### 기본 설정
```python
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
ROBOT_TOOL = "Tool Weight"      # 워크셀 등록된 툴 무게
ROBOT_TCP = "GripperDA_v1"      # 워크셀 등록된 TCP
```

### 속도/가속도 프리셋
| 이름 | 속도 (mm/s) | 가속도 (mm/s²) | 용도 |
|-----|-----------|------------|------|
| V_FAST / A_FAST | 70 | 70 | 빠른 이동 |
| V_SLOW / A_SLOW | 20 | 20 | 정밀 작업 |
| VJ / AJ | 70 | 70 | 관절 공간 이동 |

### 경로점(Way-point)
```python
HOME_P_LIST = [367.22, 3.83, 201.28, 158.41, 179.96, 158.79]  # 홈 포지션
q_mid = [26.01, 17.70, 87.27, 0.13, 75.06, 26.03]            # 중간 경로점

q_s1 = [
    [30.62, 18.12, 122.74, -146.41, 57.81, 161.67],   # 선반1-위치1
    [40.95, 24.14, 113.02, -133.93, 59.29, 152.80],   # 선반1-위치2
    [49.59, 30.45, 102.15, -123.56, 61.19, 144.29],   # 선반1-위치3
]

q_s2 = [
    [-31.45, 19.05, 69.88, 0.07, 91.00, -30.92],      # 선반2-위치1
    [-28.24, 27.55, 54.35, 0.11, 98.04, -27.66],      # 선반2-위치2
    [-25.60, 37.51, 39.08, 0.17, 103.36, -24.97],     # 선반2-위치3
]
```

### 작업 파라미터
```python
INSPECT_TIME = 2.0              # 검사 시간 (Stage A)
S1_PICK_PUSH_X = 20.0           # Stage A: X축 전진 거리
S1_PICK_PULL_X = -10.0          # Stage A: X축 후진 거리
S1_BEFORE_CLOSE_WAIT = 0.5      # Gripper 폐쇄 전 대기
S3_PITCH_DELTA_DEG = 20.0       # Stage B: 피치 회전각
S3_PITCH_SIGN = -1.0            # 피치 회전 방향
```

---

## 🎯 Stage A: 선반1(S1) → 선반2(S2) 왕복 (3사이클)

### 동작 흐름
```
1. go_home()                    ← 홈 위치로 이동
2. [반복 3회: i = 0, 1, 2]
   ├─ open_gripper()           ← Gripper 개방 (PIN2)
   ├─ goj(q_s1[i])             ← 선반1 위치i로 이동 (관절)
   ├─ move_rel_x(+20mm)        ← X축 전진 (집기 동작)
   ├─ wait(0.5초)
   ├─ close_gripper()          ← Gripper 폐쇄 (PIN1)
   ├─ move_rel_x(-10mm)        ← X축 후진 (물건 들기)
   ├─ goj(q_s2[i])             ← 선반2 위치i로 이동
   ├─ wait(2초)                ← 검사/처리 시간
   └─ open_gripper()           ← Gripper 개방 (놓기)
```

### 핵심 코드
```python
def stageA_s1_s2_roundtrip_3cycles_no_home():
    go_home()
    wait(0.3)
    
    for i in range(3):
        open_gripper()
        wait(0.1)
        
        goj(q_s1[i])                           # 선반1로
        wait(0.2)
        
        move_rel_x(S1_PICK_PUSH_X, ...)        # 앞으로
        wait(S1_BEFORE_CLOSE_WAIT)
        
        close_gripper()                        # 집기
        wait(0.2)
        
        move_rel_x(S1_PICK_PULL_X, ...)        # 뒤로
        wait(0.1)
        
        goj(q_s2[i])                           # 선반2로
        wait(0.2)
        
        wait(INSPECT_TIME)                     # 검사
        
        open_gripper()                         # 놓기
        wait(0.2)
```

---

## 🎯 Stage B: 선반2(S2) → 선반3(S3) 이송 (3사이클)

### 동작 흐름
```
[반복 3회: i = 0, 1, 2]
├─ goj(q_s2[i])                    ← 선반2 위치i로 이동
├─ close_gripper()                 ← Gripper 폐쇄 (집기)
├─ goj(q_mid)                      ← 중간 경로점으로 이동
├─ 현재 포즈 저장 (cur6)
├─ movel(피치+20도 기울임)          ← 자세만 회전
├─ open_gripper()                  ← Gripper 개방 (놓기)
├─ movel(원래 자세)                ← 자세 복귀
└─ goj(q_mid)                      ← 중간점으로 복귀
```

### 핵심 코드
```python
def stageB_s2_s3_pick_qs2_via_qmid_tilt_only_3cycles():
    for i in range(3):
        # 1) 선반2에서 물건 집기
        goj(q_s2[i])
        wait(0.2)
        close_gripper()
        wait(0.2)
        
        # 2) 중간점으로 이동
        goj(q_mid)
        wait(0.2)
        
        # 3) 현재 위치에서 자세만 기울여서 놓기
        cur6 = _pose_from_current()
        p_work = _pose_same(cur6)
        p_tilt = _pose_tilt_from_pose(cur6, S3_PITCH_SIGN * S3_PITCH_DELTA_DEG)
        
        movel(p_tilt, vel=V_SLOW, acc=A_SLOW)  # 기울임
        wait(0.1)
        open_gripper()                         # 놓기
        wait(0.2)
        
        movel(p_work, vel=V_SLOW, acc=A_SLOW)  # 자세 복귀
        wait(0.1)
        
        # 4) 다음 사이클 준비
        goj(q_mid)
        wait(0.1)
```

---

## 🔧 주요 API 함수

### 이동 명령
| 함수 | 매개변수 | 설명 |
|------|--------|------|
| `movej(q, vel, acc)` | 관절각 배열 | 관절 공간에서 선형 이동 |
| `movel(pose, vel, acc)` | 포즈 객체 | 직교 좌표에서 직선 이동 |
| `goj(q)` | 관절각 배열 | `movej()`의 래퍼 (고정 속도) |
| `go_home()` | 없음 | 홈 위치로 이동 |

### 포즈 관련
| 함수 | 설명 |
|------|------|
| `posx([x, y, z, A, B, C])` | 6D 포즈 객체 생성 |
| `get_current_posx()` | 현재 포즈 조회 |
| `_extract_posx6(p)` | 포즈에서 6개 값 추출 |
| `_pose_from_current()` | 현재 포즈를 튜플로 |
| `_pose_same(p6)` | 포즈 복사 |
| `_pose_tilt_from_pose(p6, pitch_delta)` | 피치 회전된 새 포즈 생성 |

### 제어 명령
| 함수 | 설명 |
|------|------|
| `set_digital_output(pin, ON/OFF)` | 디지털 출력 제어 (Gripper) |
| `wait(sec)` | 지정된 시간 대기 |
| `set_tool(name)` | 툴 무게 설정 |
| `set_tcp(name)` | TCP 좌표 설정 |

### Gripper 제어
```python
def open_gripper():
    set_digital_output(2, ON)   # PIN 2 활성화
    wait(1.00)
    set_digital_output(2, OFF)  # PIN 2 비활성화

def close_gripper():
    set_digital_output(1, ON)   # PIN 1 활성화
    wait(1.00)
    set_digital_output(1, OFF)  # PIN 1 비활성화
```

---

## 🔢 좌표계 및 포즈 형식

### 6D 포즈 (x, y, z, A, B, C)
- **x, y, z**: 위치 (mm)
- **A, B, C**: 회전 (도)
  - A: Roll (주축 중심 회전)
  - B: Pitch (앞뒤 기울임)
  - C: Yaw (좌우 회전)

### 관절 공간 (q)
6개 관절의 각도 배열:
```python
q = [J1, J2, J3, J4, J5, J6]  # 단위: 도(degree)
```

---

## ⚡ 실행 흐름 요약

```
1. 로봇 초기화
   ├─ ROS 2 초기화
   ├─ 툴/TCP 설정
   └─ 설정값 출력

2. Stage A (3사이클)
   └─ 선반1 → 선반2 픽앤플레이스

3. Stage B (3사이클)
   └─ 선반2 → 선반3 픽앤플레이스 (자세 기울임)

4. 종료
   ├─ 홈 위치 복귀
   └─ ROS 2 종료
```

---

## 📌 주요 특징

- ✅ **3-사이클 반복**: Stage A, B 각각 3번 반복
- ✅ **정밀한 상대 이동**: `move_rel_x()`로 X축 상대 이동
- ✅ **자세 제어**: Stage B에서 피치만 회전하여 물건 배치
- ✅ **안전한 시간 관리**: `wait()`로 각 동작 사이 대기
- ✅ **에러 처리**: try-catch로 예외 상황 관리
- ✅ **ROS 2 통합**: rclpy로 ROS 2 생태계 연동

---

## 🔍 유틸리티 함수

### 각도 정규화
```python
def _wrap_deg(a):
    """각도를 -180 ~ 180도 범위로 정규화"""
    while a > 180.0:
        a -= 360.0
    while a < -180.0:
        a += 360.0
    return a
```

### 상대 이동
```python
def move_rel_x(dx, vel=V_SLOW, acc=A_SLOW):
    """현재 위치에서 X축 방향으로 상대 이동"""
    p = get_current_posx()
    x, y, z, A, B, C = _extract_posx6(p)
    movel(posx([x + dx, y, z, A, B, C]), vel=vel, acc=acc)
```

---

**문서 작성일**: 2026년 1월 20일

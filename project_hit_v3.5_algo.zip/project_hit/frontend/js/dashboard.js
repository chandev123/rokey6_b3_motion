// dashboard.js - Project Hit Dashboard

const FIREBASE_URL = "https://rokey-b-3-default-rtdb.firebaseio.com";
const API_KEY = "AIzaSyCVaEaIp1lyqLlvKR7rBFDpLNyp3Iavx48";
const DATA_PATH = "/task_runner";  // UI Node에서 사용하는 경로

let lastUpdateTime = null;
let updateCount = 0;
let errorCount = 0;

// ========== Update Functions ==========
function updateStatus(status) {
    const statusBox = document.getElementById('status-box');
    if (statusBox) {
        statusBox.className = 'status-indicator ' + status;
        statusBox.textContent = status;
    }
}

function updateJointValues(joints) {
    if (!Array.isArray(joints) || joints.length < 6) {
        console.warn('⚠️ Invalid joints data:', joints);
        return;
    }
    
    for (let i = 0; i < 6; i++) {
        const angle = joints[i];
        
        // Update gauge
        const gaugeFill = document.getElementById(`joint-gauge-${i}`);
        if (gaugeFill) {
            const percentage = ((angle + 180) / 360) * 100;
            gaugeFill.style.width = Math.max(0, Math.min(100, percentage)) + '%';
        }
        
        // Update value text
        const gaugeValue = document.getElementById(`joint-value-${i}`);
        if (gaugeValue) {
            gaugeValue.textContent = angle.toFixed(1) + '°';
        }
    }
}

function updateForceDisplay(force, torque, forceMag) {
    // Force values
    const forceX = document.getElementById('force-x');
    const forceY = document.getElementById('force-y');
    const forceZ = document.getElementById('force-z');
    const forceMagEl = document.getElementById('force-mag');
    
    if (force) {
        if (forceX) forceX.textContent = (force.x || 0).toFixed(2);
        if (forceY) forceY.textContent = (force.y || 0).toFixed(2);
        if (forceZ) forceZ.textContent = (force.z || 0).toFixed(2);
    }
    if (forceMagEl) forceMagEl.textContent = (forceMag || 0).toFixed(2);
    
    // Torque values
    const torqueX = document.getElementById('torque-x');
    const torqueY = document.getElementById('torque-y');
    const torqueZ = document.getElementById('torque-z');
    
    if (torque) {
        if (torqueX) torqueX.textContent = (torque.x || 0).toFixed(2);
        if (torqueY) torqueY.textContent = (torque.y || 0).toFixed(2);
        if (torqueZ) torqueZ.textContent = (torque.z || 0).toFixed(2);
    }
    
    // Color coding based on force magnitude
    const forceElements = [forceX, forceY, forceZ, forceMagEl];
    forceElements.forEach(el => {
        if (el) {
            el.classList.remove('force-safe', 'force-warning', 'force-danger');
            if (forceMag > 30) {
                el.classList.add('force-danger');
            } else if (forceMag > 15) {
                el.classList.add('force-warning');
            } else {
                el.classList.add('force-safe');
            }
        }
    });
}

function updateDebugInfo(status, timestamp) {
    const debugStatus = document.getElementById('debug-status');
    const debugTimestamp = document.getElementById('debug-timestamp');
    
    if (debugStatus) {
        const now = new Date().toLocaleTimeString('ko-KR');
        debugStatus.innerHTML = `
            <div>✅ Last Update: ${now}</div>
            <div>📈 Updates: ${updateCount} | ❌ Errors: ${errorCount}</div>
            <div>Status: ${status || 'WAITING'}</div>
        `;
    }
    
    if (debugTimestamp && timestamp) {
        const updateDate = new Date(timestamp * 1000).toLocaleString('ko-KR');
        debugTimestamp.textContent = `Server time: ${updateDate}`;
    }
}

// ========== Firebase Data Polling ==========
function pollRobotData() {
    const dataUrl = `${FIREBASE_URL}${DATA_PATH}.json?auth=${API_KEY}`;
    
    fetch(dataUrl, { method: 'GET' })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (!data) {
                console.log('⚠️ No data received from Firebase');
                updateDebugInfo('No data', null);
                return;
            }
            
            updateCount++;
            lastUpdateTime = new Date();
            
            // Update status
            if (data.status) {
                updateStatus(data.status);
            }
            
            // Update joints
            if (data.joints) {
                updateJointValues(data.joints);
            }
            
            // Update force/torque
            updateForceDisplay(data.force, data.torque, data.force_mag);
            
            // Update connection status
            const connStatus = document.getElementById('connection-status');
            const robotConn = document.getElementById('robot-connection');
            if (connStatus) {
                connStatus.textContent = '🟢 Connected';
                connStatus.className = 'status-connected';
            }
            if (robotConn) {
                robotConn.textContent = data.connected ? '✅ OK' : '❌ Disconnected';
                robotConn.style.color = data.connected ? '#4caf50' : '#f44336';
            }
            
            // Update error display
            const lastError = document.getElementById('last-error');
            if (lastError) {
                lastError.textContent = data.error || '-';
            }
            
            updateDebugInfo(data.status, data.timestamp);
        })
        .catch(error => {
            errorCount++;
            console.error('❌ Polling error:', error);
            
            const connStatus = document.getElementById('connection-status');
            if (connStatus) {
                connStatus.textContent = '🔴 Disconnected';
                connStatus.className = 'status-disconnected';
            }
            
            updateDebugInfo('Connection Error', null);
        });
}

// ========== Control Commands ==========
function sendCommand(command) {
    console.log('🎮 Sending command:', command);
    
    const commandUrl = `${FIREBASE_URL}${DATA_PATH}/command.json?auth=${API_KEY}`;
    
    const commandData = {
        cmd: command,
        timestamp: new Date().toISOString()
    };
    
    fetch(commandUrl, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(commandData)
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.json();
    })
    .then(data => {
        console.log('✅ Command sent successfully:', command);
        // Visual feedback
        updateStatus(command === 'START' ? 'RUNNING' : command);
    })
    .catch(error => {
        console.error('❌ Error sending command:', error);
        alert('명령 전송 실패: ' + error.message);
    });
}

// ========== Button Event Listeners ==========
document.addEventListener('DOMContentLoaded', function() {
    const btnStart = document.getElementById('btn-start');
    const btnPause = document.getElementById('btn-pause');
    const btnHome = document.getElementById('btn-home');
    const btnEmergencyStop = document.getElementById('btn-emergency-stop');

    if (btnStart) {
        btnStart.addEventListener('click', function() {
            console.log('▶️ START button clicked');
            sendCommand('START');
        });
    }

    if (btnPause) {
        btnPause.addEventListener('click', function() {
            console.log('⏸️ PAUSE button clicked');
            sendCommand('PAUSE');
        });
    }

    if (btnHome) {
        btnHome.addEventListener('click', function() {
            console.log('🏠 HOME button clicked');
            sendCommand('HOME');
        });
    }

    if (btnEmergencyStop) {
        btnEmergencyStop.addEventListener('click', function() {
            console.log('🛑 EMERGENCY STOP button clicked');
            if (confirm('정말로 긴급 정지를 실행하시겠습니까?')) {
                sendCommand('EMERGENCY_STOP');
            }
        });
    }

    // Initialize
    console.log('🚀 Task Runner Dashboard initializing...');

    const connStatus = document.getElementById('connection-status');
    if (connStatus) {
        connStatus.textContent = '🟡 Connecting...';
    }

    // Initial poll
    pollRobotData();

    // Start polling robot data every 500ms
    setInterval(pollRobotData, 500);

    console.log('✅ Dashboard initialized');
});

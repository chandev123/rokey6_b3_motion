import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import DR_init
import time
# from .get_posx import GetPosx

ROBOT_ID='dsr01'
ROBOT_MODEL='m0609'
ROBOT_TOOL="Tool Weight"
ROBOT_TCP="GripperDA_v1"

VELOCITY=60
ACC=60

DR_init.__dsr__id=ROBOT_ID
DR_init.__dsr__model=ROBOT_MODEL

def initialize_robot():
    from DSR_ROBOT2 import set_tool,set_tcp
    set_tool(ROBOT_TOOL)
    set_tcp(ROBOT_TCP)
    
    print("Robot initialized with the following settings:")
    print("#"*50)
    print(f"ROBOT_ID: {ROBOT_ID}")
    print(f"ROBOT_MODEL: {ROBOT_MODEL}")
    print(f"ROBOT_TCP: {ROBOT_TCP}")
    print(f"ROBOT_TOOL: {ROBOT_TOOL}")
    print(f"VELOCITY: {VELOCITY}")
    print(f"ACC: {ACC}")
    print("#"*50)

def perform_task(node, publisher, publish_and_log=True):
    from DSR_ROBOT2 import get_current_posx
    ##### 출력 중인 서비스를 직접 구독 ######
    # get_posx = GetPosx()
    # future = get_posx.send_request()
    
    # while not future.done():
    #     rclpy.spin_once(get_posx)
        
    # position = future.result()
    # node.get_logger().info(f"Position: {position}")

    ##### 직접 호출 #####
    position, _ = get_current_posx()
    
    if publish_and_log:
        node.get_logger().info(f"Position: {position}")
        
        msg = Float64MultiArray()
        msg.data = list(position)
        publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node("hw_node", namespace=ROBOT_ID) # Renamed node to hw_node to avoid conflict/confusion with get_posx class
    publisher = node.create_publisher(Float64MultiArray, '/dsr01/aux_control/get_current_posx', 10)

    node.get_logger().info("Performing task...")
    DR_init.__dsr__node = node
    
    count = 0
    try:
        initialize_robot()
        while rclpy.ok():
            count += 1
            # perform_task(node, publisher, publish_and_log=(count % 10 == 0))
            # time.sleep(0.1) 10Hz에서는 작동 멈춤
            perform_task(node, publisher, publish_and_log=True)
            time.sleep(1)
    except KeyboardInterrupt:
        node.get_logger().info("KeyboardInterrupt, shutting down...")
    except Exception as e:
        node.get_logger().info(f'An unexpected error occurred: {e}')
    finally:
        node.get_logger().info("Shutting down...")
        rclpy.shutdown()

if __name__ == '__main__':
    main()    

import rclpy
from rclpy.node import Node
from dsr_msgs2.srv import GetCurrentPosx

class GetPosx(Node):
    def __init__(self):
        super().__init__('get_posx')
        self.client = self.create_client(GetCurrentPosx, 'dsr01/aux_control/get_current_posx')

        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')

    def send_request(self):
        self.request = GetCurrentPosx.Request()
        return self.client.call_async(self.request)

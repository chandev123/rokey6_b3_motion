import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from sensor_msgs.msg import JointState
from rclpy.qos import QoSProfile
import time
import math

# DSR Imports
import DR_init

# Global Constants
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
ROBOT_TOOL = "Tool Weight"
ROBOT_TCP = "GripperDA_v1"
VELOCITY = 60
ACC = 60
CONNECTION_TIMEOUT = 1.5

# DR_init Settings (Global Scope matching move_basic)
DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

# Global Variables (Node & Executor Handles)
hw_node = None
dsr_node = None
executor = None

# State Variables
last_joint_state = None
last_topic_time = 0.0

def initialize_robot():
    """로봇의 Tool과 TCP를 설정 (move_basic style)"""
    # move_basic와 동일하게 필요한 기능 임포트
    from DSR_ROBOT2 import set_tool, set_tcp
    
    global hw_node

    # Tool과 TCP 설정
    set_tool(ROBOT_TOOL)
    set_tcp(ROBOT_TCP)

    # 설정값 출력 (Logger 사용)
    hw_node.get_logger().info("Initializing robot with the following settings:")
    hw_node.get_logger().info(f"ROBOT_ID: {ROBOT_ID}")
    hw_node.get_logger().info(f"ROBOT_MODEL: {ROBOT_MODEL}")
    hw_node.get_logger().info(f"ROBOT_TCP: {ROBOT_TCP}")
    hw_node.get_logger().info(f"ROBOT_TOOL: {ROBOT_TOOL}")
    hw_node.get_logger().info(f"VELOCITY: {VELOCITY}")
    hw_node.get_logger().info(f"ACC: {ACC}")

def perform_task():
    """로봇 상태 모니터링 수행 (ROS Spin)"""
    global hw_node, executor
    
    hw_node.get_logger().info("Performing task (Monitoring Status)...")
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        hw_node.get_logger().info('KeyboardInterrupt, shutting down...')
    finally:
        shutdown()

def shutdown():
    global executor, hw_node, dsr_node
    if executor:
        executor.shutdown()
    if hw_node:
        hw_node.destroy_node()
    if dsr_node:
        dsr_node.destroy_node()
    rclpy.shutdown()

def joint_callback(msg):
    global last_joint_state, last_topic_time
    last_joint_state = msg
    last_topic_time = time.time()

def timer_callback():
    global hw_node, last_joint_state, last_topic_time
    
    current_time = time.time()
    time_diff = current_time - last_topic_time

    if last_joint_state is None:
         hw_node.get_logger().warn('Waiting for connection... (No data received yet)')
    elif time_diff > CONNECTION_TIMEOUT:
         hw_node.get_logger().error(f'DISCONNECTED (Last msg: {time_diff:.1f}s ago)')
    else:
         hw_node.get_logger().info(f'Robot Connection: ALIVE (Latency: {time_diff:.3f}s)')

def main(args=None):
    global hw_node, dsr_node, executor, last_topic_time
    
    rclpy.init(args=args)
    
    # 1. Main HW Node (Monitor)
    hw_node = rclpy.create_node('hw_node')
    
    # 2. Separate Node for DSR_ROBOT2 (Required for DR_init to function/connect)
    dsr_node = rclpy.create_node('dsr_internal_node', namespace=ROBOT_ID)
    
    # 3. Initialize DR_init
    DR_init.__dsr__node = dsr_node

    qos_profile = QoSProfile(depth=10)

    # Subscribers
    hw_node.create_subscription(
        JointState,
        f'/{ROBOT_ID}/joint_states',
        joint_callback,
        qos_profile
    )

    # Timer
    hw_node.create_timer(1.0, timer_callback)
    last_topic_time = time.time()
    
    # Executor Setup
    executor = MultiThreadedExecutor()
    executor.add_node(hw_node)
    executor.add_node(dsr_node)

    # 4. Initialize & Perform
    initialize_robot()
    perform_task()

if __name__ == '__main__':
    main()
